﻿using System.Drawing;

namespace GraphicEx
{
    public interface IFillable
    {
        void setFill(bool fill, Brush brush);
    }
}