﻿using System;
using System.Windows.Forms;

namespace SubmitWindow
{
    public partial class treeView : Form
    {
        public treeView()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            notifyIcon1.ShowBalloonTip(5000, "Medicine Packet", "Receive " + numericUpDown1.Value + " packs", ToolTipIcon.Warning);
        }
    }
}