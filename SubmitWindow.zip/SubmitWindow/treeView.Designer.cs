﻿using System.ComponentModel;
using System.Windows.Forms;

namespace SubmitWindow
{
    partial class treeView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Acetaminophen");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Warfarin");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("Thuốc nhập", new System.Windows.Forms.TreeNode[] { treeNode1, treeNode2 });
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("Paracetamol");
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("Salbutamol");
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("Thuốc trong nước", new System.Windows.Forms.TreeNode[] { treeNode4, treeNode5 });
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("Thuốc ", new System.Windows.Forms.TreeNode[] { treeNode3, treeNode6 });
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(treeView));
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // treeView1
            // 
            this.treeView1.Location = new System.Drawing.Point(183, 93);
            this.treeView1.Name = "treeView1";
            treeNode1.Name = "";
            treeNode1.Text = "Acetaminophen";
            treeNode2.Name = "";
            treeNode2.Text = "Warfarin";
            treeNode3.Name = "";
            treeNode3.Text = "Thuốc nhập";
            treeNode4.Name = "";
            treeNode4.Text = "Paracetamol";
            treeNode5.Name = "";
            treeNode5.Text = "Salbutamol";
            treeNode6.Name = "";
            treeNode6.Text = "Thuốc trong nước";
            treeNode7.Name = "";
            treeNode7.Text = "Thuốc ";
            this.treeView1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] { treeNode7 });
            this.treeView1.Size = new System.Drawing.Size(383, 131);
            this.treeView1.TabIndex = 0;
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            this.notifyIcon1.Text = "notifyIcon1";
            this.notifyIcon1.Visible = true;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(413, 292);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(256, 20);
            this.numericUpDown1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(413, 259);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(240, 40);
            this.label1.TabIndex = 2;
            this.label1.Text = "Số lượng thuốc";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(304, 354);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(172, 41);
            this.button1.TabIndex = 3;
            this.button1.Text = "OK";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // treeView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.treeView1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "treeView";
            this.Text = "treeView";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Button button1;

        private System.Windows.Forms.Label label1;

        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.NumericUpDown numericUpDown1;

        private System.Windows.Forms.TreeView treeView1;

        #endregion
    }
}